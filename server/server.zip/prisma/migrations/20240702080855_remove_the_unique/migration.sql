-- DropIndex
DROP INDEX `UserDetails_email_key` ON `userdetails`;
