-- AlterTable
ALTER TABLE `userdetails` ALTER COLUMN `username` DROP DEFAULT;
