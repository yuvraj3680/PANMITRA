-- AlterTable
ALTER TABLE `msdlesign` MODIFY `dateOfBirth` VARCHAR(191) NOT NULL;
