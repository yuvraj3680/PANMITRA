-- AlterTable
ALTER TABLE `pancustomer` MODIFY `dob` VARCHAR(191) NOT NULL;
