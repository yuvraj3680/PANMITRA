-- AlterTable
ALTER TABLE `minorpan` MODIFY `dateOfBirth` VARCHAR(191) NOT NULL;

-- AlterTable
ALTER TABLE `pancustomer` MODIFY `dob` VARCHAR(191) NOT NULL;
