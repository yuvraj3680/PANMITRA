/*
  Warnings:

  - You are about to drop the column `captcha` on the `userdetails` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `userdetails` DROP COLUMN `captcha`;
